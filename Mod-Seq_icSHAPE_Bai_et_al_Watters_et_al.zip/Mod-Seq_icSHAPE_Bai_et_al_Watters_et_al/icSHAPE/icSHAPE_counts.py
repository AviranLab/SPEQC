#!/usr/bin/env python

import os
import sys
import subprocess
import time
import datetime
import csv
import copy
import threading
import Queue

class geneModCount(object):
    
    def __init__(self, name, chrms, strain, featureType, posStart, posEnd):
        self.name = name
        self.chrms = chrms
        self.strain = strain
        self.featureType = featureType
        self.Start = int(posStart)
        self.End = int(posEnd)
        self.length = self.End - self.Start+1
        self.count = "NA"
        self.countPerNt = "NA"
        self.countArray = [0 for i in xrange(self.length)]
        self.description = [self.name, self.chrms, self.strain, self.featureType, self.Start, self.End, self.length, self.count, self.countPerNt]   
    
    def getDescription(self):
        self.description = [self.name, self.chrms, self.strain, self.featureType, self.Start, self.End, self.length, self.count, self.countPerNt]


#count ModStops on each position
inputfiles = ["dmso.1.intersect.tab", "dmso.2.intersect.tab"]
outputfiles = ["CountMod_dmso.1.tab", "CountMod_dmso.2.tab"]

for i in xrange(2):
    fh = open(inputfiles[i], 'r')
    genes = dict()
    
    """.tab file format:
    0       1       2       3       4       5       6       7       8
    chr     rStart  rEnd    rName   +/-     type    geneS   geneEnd geneName
    """
            
    line = fh.readline()
    while (line):
        line = line.split()
        #print line
        gene = line[8]
        #print gene
        if (int(line[1]) > int(line[6]) and int(line[2]) < int(line[7])):#if mod-stop is inside gene
            if gene not in genes:
                genes[gene]=geneModCount(line[8], line[0], *line[4:8])
            if line[4] == '+':
                #print len(genes[gene].countArray)
                #print int(line[1])-int(line[6])-1
                if int(line[1])-int(line[6])-1 < len(genes[gene].countArray):
                    genes[gene].countArray[int(line[1])-int(line[6])-1]+=1
            elif line[4] == '-':
                genes[gene].countArray[int(line[7])-int(line[2])-1]+=1
                
        line=fh.readline()
    #print genes[gene]
    fh.close()
    
    for gene in genes:           
        genes[gene].count = sum(genes[gene].countArray)
        genes[gene].countPerNt = float(genes[gene].count)/genes[gene].length
        genes[gene].getDescription()
        
    fh = open(outputfiles[i], 'w')
    mywriter = csv.writer(fh, delimiter=' ')
    for gene in genes:
        #if genes[gene].countPerNt > 1:
        mywriter.writerow([">"]+genes[gene].description)
        mywriter.writerow(genes[gene].countArray)
    fh.close()

