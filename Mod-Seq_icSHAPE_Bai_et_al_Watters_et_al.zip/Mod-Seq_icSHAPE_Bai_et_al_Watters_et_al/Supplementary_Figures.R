#1. SHAPE-Seq
load("SHAPE-Seq.RData")

dat <- data.frame(mean= mean_SNR_diff, gini=gini_snr_diff, pcc=PCC_diff)
dat$gini <- replace(dat$gini, which(dat$gini<=0.25), 0.25)
dat$gini <- replace(dat$gini, which(dat$gini<=0.5 & dat$gini>0.25), 0.5)
dat$gini <- replace(dat$gini, which(dat$gini<=0.75 & dat$gini>0.5), 0.75)
dat$gini <- replace(dat$gini, which(dat$gini>0.75), 1)
dat$gini <- as.character(dat$gini)
dat$gini[which(dat$gini == "0.25")] <- "0.0 - 0.25"
dat$gini[which(dat$gini == "0.5")] <- "0.25 - 0.5"
dat$gini[which(dat$gini == "0.75")] <- "0.5 - 0.75"
dat$gini[which(dat$gini == "1")] <- "0.75 - 1.0"
dat$gini <- factor(dat$gini, levels = c("0.0 - 0.25", "0.25 - 0.5", "0.5 - 0.75", "0.75 - 1.0"))

tiff("FigS_clipping_shape-seq_1.tiff", res=300, width=2102.361, height= 707, unit="px")
ggplot(data=dat, aes(x=mean, y=pcc)) + geom_point(aes(shape= dat$gini)) + xlim(0, 50) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.3))+ 
  labs(y="Pearson correlation", x= "Mean SNR", shape="Gini index") +
  scale_shape_manual(values=c("0.0 - 0.25"= 0, "0.25 - 0.5"= 1, "0.5 - 0.75" = 2, "0.75 - 1.0" =3 ))
dev.off()  

dat <- data.frame(mean= mean_SNR_diff_clipped, gini=gini_snr_diff_clipped, pcc=PCC_diff)
dat$gini <- replace(dat$gini, which(dat$gini<=0.25), 0.25)
dat$gini <- replace(dat$gini, which(dat$gini<=0.5 & dat$gini>0.25), 0.5)
dat$gini <- replace(dat$gini, which(dat$gini<=0.75 & dat$gini>0.5), 0.75)
dat$gini <- replace(dat$gini, which(dat$gini>0.75), 1)
dat$gini <- as.character(dat$gini)
dat$gini <- as.character(dat$gini)
dat$gini[which(dat$gini == "0.25")] <- "0.0 - 0.25"
dat$gini[which(dat$gini == "0.5")] <- "0.25 - 0.5"
dat$gini[which(dat$gini == "0.75")] <- "0.5 - 0.75"
dat$gini[which(dat$gini == "1")] <- "0.75 - 1.0"
dat$gini <- factor(dat$gini, levels = c("0.0 - 0.25", "0.25 - 0.5", "0.5 - 0.75", "0.75 - 1.0"))

tiff("FigS_clipping_shape-seq_2.tiff", res=300, width=2102.361, height= 707, unit="px")
ggplot(data=dat, aes(x=mean, y=pcc)) + geom_point(aes(shape= dat$gini)) + xlim(0, 10) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.3))+ 
  labs(y="Pearson correlation", x= "Mean SNR", shape="Gini index") +
  scale_shape_manual(values=c("0.0 - 0.25"= 0, "0.25 - 0.5"= 1, "0.5 - 0.75" = 2, "0.75 - 1.0" =3 ))
dev.off()  

# SHAPE-Seq talkish formula

load("SHAPE-Seq_ratio.RData")
ty <- c(0:99.99)/100
tx <- sqrt(ty/(1-ty))
tx <- tx +median(mean_SNR_talkish_shifted_clipped - (sqrt(PCC_talkish_shifted/(1-(PCC_talkish_shifted)))), na.rm=T)

tiff("FigS_ratio_mean_SNR_PCC.tiff")
plot(y=PCC_talkish_shifted, x=mean_SNR_talkish_shifted_clipped, 
     xlim=c(0,max(mean_SNR_talkish_shifted_clipped)),
     xlab= "Mean SNR", ylab="Pearson correlation")
lines(x= tx, y=ty)
dev.off()

#2. Yun Bai's data
rm(list=ls())
load("Bai_HIV_RRE.RData")
residue_SNR <- c()
residue_SNR[which(summary_snr_binding_sites$zone == "green")] <- "> 5"
residue_SNR[which(summary_snr_binding_sites$zone == "yellow")] <- "3 - 5"
residue_SNR[which(summary_snr_binding_sites$zone == "red")] <- "< 3"

summary_snr_binding_sites$residue_SNR <- residue_SNR
summary_snr_binding_sites$residue_SNR <- factor(summary_snr_binding_sites$residue_SNR,
                                                levels= c("> 5", "3 - 5", "< 3"))

levels(summary_snr_binding_sites$name) <- c("RRE alone", 
                                            "Rev-RRE complex",
                                            "Replicate 1",
                                            "Replicate 2",
                                            "Replicate 3")

tiff("FigS_differential_signal_bai.tiff", res=300, width=2102.361, height= 707, unit="px")
ggplot(summary_snr_binding_sites, aes(x=factor(1), y=fraction, fill = factor(residue_SNR))) + 
  geom_bar(width = 1, stat="identity")+
  facet_grid(facets=. ~ name) + 
  coord_polar(theta="y")+scale_fill_manual(values= c("> 5" = "#9AF257", 
                                                     "3 - 5" = "#E2F257", 
                                                     "< 3" = "#F26257")) +
  theme(axis.title.x=element_blank(), axis.title.y=element_blank(), 
        axis.text.x = element_text(size = 4),
        axis.text.y=element_blank(), axis.ticks=element_blank(), 
        panel.background=element_blank(), 
        legend.position="bottom", legend.box= "horizontal",
        strip.text.x = element_text(size = 5)) +
  guides(fill = guide_legend(title= "residue SNR"))
dev.off()

# 3. TPP riboswitch
load("TPP_riboswitch.RData")

SNR <- data.frame(SNR=c(SNR0, SNR5, SNR_inter_norm), type= c(rep("No ligand", 98),
                                                             rep("With ligand", 98),
                                                             rep("Between conditions", 98)))

SNR$SNR[which(SNR$SNR > 35)] <- 35
SNR$type <- factor(SNR$type, levels= c("No ligand", "With ligand", "Between conditions"))

tiff("FigS_differential_signal_tpp.tiff", res=300, width=1502.361, height= 707, unit="px")
ggplot(SNR, aes(factor(type), SNR)) +
  geom_rect(ymin=5, ymax= Inf, xmin=-Inf, xmax=Inf, fill= "#6BD962", alpha=0.003)+
  geom_rect(ymin=3, ymax= 5, xmin=-Inf, xmax=Inf, fill= "#D1D088", alpha=0.003)+
  geom_rect(ymin=0, ymax= 3, xmin=-Inf, xmax=Inf, fill= "#D16D8C", alpha=0.003) + 
  stat_boxplot(geom ='errorbar', stat_params = list(width = 0.5))+
  geom_boxplot(fatten=0, outlier.colour="#73797A", outlier.size= 2) + 
  scale_y_continuous(limits=c(0,36))+
  stat_summary(fun.y=mean, geom="line", aes(group=1)) +
  theme(panel.border = element_rect(colour = "black", fill=NA))+
  labs(x= NULL)+theme(axis.text.x = element_text(colour="black"))
dev.off()

# 4. icSHAPE

# icSHAPE 1

for (sizes in c("100M", "200M", "300M")) {
  for (env in c("invitro", "invivo")) {
    load(paste0("./icSHAPE",
                "/", sizes, "/", env, ".", sizes, ".Rdata"))
    assign(paste("snr", env, sizes, sep="_"), snr)
  }
}

genes <- intersect(snr_invitro_100M$genes, snr_invivo_100M$genes)

fractions <- data.frame(condition=c(), fraction=c(), zone=c(), overall_counts=c())

for (sizes in c("100M", "200M", "300M")) {
  for (env in c("invitro", "invivo")) {
    curr <- get(paste("snr", env, sizes, sep="_"))$mean_snr_clipped
    curr <- curr[which(get(paste("snr", env, sizes, sep="_"))$genes %in% genes )]
    print(length(curr))
    curr_cov <- sum(ceiling(get(paste("snr", env, sizes, sep="_"))$cov * get(paste("snr", env, sizes, sep="_"))$len), na.rm=T)
    
    inf <- strsplit(env, split="n")[[1]]
    inf <- paste0(inf[1], "n ", inf[2], ",", sizes)
    fractions <- rbind(fractions, data.frame(condition= inf, 
                                             fraction=length(which(curr>=5))/length(which(is.finite(curr))), 
                                             zone= "> 5", overall_counts= curr_cov))
    fractions <- rbind(fractions, data.frame(condition= inf, 
                                             fraction=length(which(curr>=3 & curr <5))/length(which(is.finite(curr))), 
                                             zone= "3 - 5", overall_counts= curr_cov))
  }
}

sizes <- paste(round(fractions$overall_counts/1E6, 2), "M")[c(1:6)*2]
p <- ggplot(data=fractions, aes(x=condition, y=fraction, fill=zone)) + geom_bar(stat="identity", colour="black") +scale_fill_manual(values=c("#88D195", "#F5F584")) 

tiff("FigS_icSHAPE_fractions.tiff", res=300, width=1502.361, height= 707, unit="px")
p + annotate("text", x = 1, y = 0.015, label = sizes[1], size=2) + 
  annotate("text", x = 2, y = 0.085, label = sizes[2], size=2) +
  annotate("text", x = 3, y = 0.015, label = sizes[3], size=2) +
  annotate("text", x = 4, y = 0.085, label = sizes[4], size=2) +
  annotate("text", x = 5, y = 0.01, label = sizes[5], size=2) +
  annotate("text", x = 6, y = 0.085, label = sizes[6], size=2) +
  guides(fill = guide_legend(override.aes = list(colour = NULL))) +
  theme(legend.key = element_rect(colour = "black"))+
  ylab("Fraction of transcripts") + xlab("Channel and starting library size") +
  theme(axis.title=element_text(size=7), axis.text= element_text(size=5),
        panel.border = element_rect(colour = "black", fill=NA, size=0.3),
        legend.title= element_text(size=5), legend.key.size= unit(0.5, "cm"),
        legend.text= element_text(size=5)) + labs(fill = "Mean SNR")
dev.off()

load("./invitro.300M.RData")

# icSHAPE 2

dat <- data.frame(mean= snr$mean_snr_clipped, gini=snr$gini_snr, pcc=snr$pcc, cov=snr$cov)
dat$gini <- replace(dat$gini, which(dat$gini<=0.25), 0.25)
dat$gini <- replace(dat$gini, which(dat$gini<=0.5 & dat$gini>0.25), 0.5)
dat$gini <- replace(dat$gini, which(dat$gini<=0.75 & dat$gini>0.5), 0.75)
dat$gini <- replace(dat$gini, which(dat$gini>0.75), 1)
dat$gini <- as.character(dat$gini)
dat$gini[which(dat$gini == "0.25")] <- "0.0 - 0.25"
dat$gini[which(dat$gini == "0.5")] <- "0.25 - 0.5"
dat$gini[which(dat$gini == "0.75")] <- "0.5 - 0.75"
dat$gini[which(dat$gini == "1")] <- "0.75 - 1.0"
dat$gini <- factor(dat$gini, levels = c("0.0 - 0.25", "0.25 - 0.5", "0.5 - 0.75", "0.75 - 1.0"))
dat$cov <- replace(dat$cov, which(dat$cov<=10), 10)
dat$cov <- replace(dat$cov, which(dat$cov<=15 & dat$cov>10), 15)
dat$cov <- replace(dat$cov, which(dat$cov<=20 & dat$cov>15), 20)
dat$cov <- replace(dat$cov, which(dat$cov<=25 & dat$cov>20), 25)
dat$cov <- replace(dat$cov, which(dat$cov>25), 30)
dat$cov <- as.character(dat$cov)
dat$cov <- replace(dat$cov, which(dat$cov== "10"), "0 - 10")
dat$cov <- replace(dat$cov, which(dat$cov== "15"), "10 - 15")
dat$cov <- replace(dat$cov, which(dat$cov== "20"), "15 - 20")
dat$cov <- replace(dat$cov, which(dat$cov== "25"), "20 - 25")
dat$cov <- replace(dat$cov, which(dat$cov== "30"), "> 25")
dat$cov <- factor(dat$cov, levels = c("0 - 10", "10 - 15", "15 - 20", "20 - 25", "> 25"))

g <- ggplot(data=dat, aes(x=mean, y=pcc)) +  
  scale_colour_brewer(palette = "Accent") +
  geom_point(aes(shape= dat$gini, colour=dat$cov), size= 0.6) +
  scale_x_continuous(limits=c(0,14), breaks=c(0, 3, 5, 10), expand = c(0, 0)) +
  scale_y_continuous(limits=c(-0.25, 1.05), expand = c(0.02, 0.02)) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.3), 
        legend.position="top", legend.margin= unit(-5, "mm"), legend.box= "horizontal",
        legend.key.size=unit(6, "mm"), legend.background=element_rect(fill="transparent",colour=NA), 
        legend.key = element_rect(fill="transparent",colour=NA),
        legend.text= element_text(size=unit(5, "mm"))) +
  labs(y="Pearson correlation", x= "Mean SNR", colour="Coverage", shape="Gini index") +
  scale_shape_manual(values=c("0.0 - 0.25"= 0, "0.25 - 0.5"= 5, "0.5 - 0.75" = 2, "0.75 - 1.0" =3 )) +
  guides(colour=guide_legend(override.aes=list(size=2)), shape= guide_legend(override.aes=list(size=2)))

dat_inset <- dat[which(dat$cov == "> 25"),]
ty <- c(0:99.99)/100
tx <- sqrt(ty/(1-ty))
tx <- tx +median(dat_inset$mean - (sqrt(dat_inset$pcc/(1-(dat_inset$pcc)))), na.rm=T)
rows_a <- nrow(dat_inset)-length(tx)
df_fit <- data.frame(y=c(ty,rep(0,rows_a)), x= c(tx, rep(0,rows_a)))
dat_inset <- cbind(dat_inset, df_fit)

load("./icSHAPE/SHAPE-Seq_pcc_mean_snr.RData")
dat_julius <- data.frame(mean= c(mean_SNR_diff_clipped, 8), pcc= c(PCC_diff, 0.1))
df1 <- data.frame(x1 = 7.8, x2 = 8.2, y1 = 0, y2 = 0)
g_inset <- ggplot(dat_inset, aes(x=mean, y=pcc)) +  
  geom_point(shape=1, colour="#386CAF", size= 0.2)+#scale_shape_discrete(solid=T) +
  geom_point(data=data.frame(x= 8, y= 0.2), aes(x=x, y=y), 
             shape=1, colour="#386CAF", size= 0.4)+
  scale_x_continuous(limits=c(0,12), breaks=c(0, 3, 5, 10), expand = c(0, 0.2)) +
  scale_y_continuous(breaks = c(0, 0.5, 1), expand = c(0.02, 0.02)) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.3))+
  labs(x=NULL, y=NULL)+
  theme(plot.background = element_rect(fill = "transparent", colour = NA),
        panel.background= element_rect(fill = "#FFFFF9", colour = NA), 
        axis.text= element_text(colour="black", size=5), panel.grid= element_blank())+
  geom_line(aes(x=x, y=y)) + 
  geom_point(data= dat_julius, aes(x=mean, y=pcc), shape=4, color="red", size=0.8)+
  annotate("text", x = 9.5, y = 0.2, label = "icSHAPE", size= 2)+
  annotate("text", x = 9.7, y = 0.1, label = "SHAPE-Seq", size= 2)+
  annotate("text", x = 9.8, y = 0, label = "Theoretical fit", size= 2)+
  annotate("rect", xmin = 7.6, xmax = 11.5, ymin = - 0.07, ymax = 0.27, alpha = 0.1)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), data = df1)

inset <- viewport(width=0.4, height=0.5, x=0.8, y=0.4)

tiff("Fig3B.tiff", res=300, width=2102.361, height= 1000, unit="px")
g
print(g_inset, vp=inset)
dev.off()


#icSHAPE 3

clip_at <- 35
cov_t <- 25 #threshold for coverage
curr_snr <- unlist(snr$snr[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)])
curr_snr <- replace(curr_snr, which(curr_snr> 35), 35)
curr_len <- snr$len[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)]
curr_genes <- paste0("*", substring(snr$genes[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)], 14, 18))
curr_pcc <- snr$pcc[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)]
curr_gini <- snr$gini_snr[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)]
curr <- data.frame(SNR=curr_snr, gene=rep(curr_genes, curr_len), pcc= rep(curr_pcc, curr_len), gini=rep(curr_gini, curr_len))
curr_gini <- replace(curr_gini, which(curr_gini<=0.75 & curr_gini>0.5), 0.75)
curr_gini <- replace(curr_gini, which(curr_gini>0.75), 1)
curr_gini <- as.character(curr_gini)
curr_gini[which(curr_gini == "0.75")] <- "0.5 - 0.75"
curr_gini[which(curr_gini == "1")] <- "0.75 - 1.0"
curr$gene <- factor(curr$gene, levels = curr_genes)

g <- ggplot(curr, aes(factor(gene), SNR, fill=pcc)) +
  geom_rect(ymin=5, ymax= Inf, xmin=-Inf, xmax=Inf, fill= "#6BD962", alpha=0.003)+
  geom_rect(ymin=3, ymax= 5, xmin=-Inf, xmax=Inf, fill= "#D1D088", alpha=0.003)+
  geom_rect(ymin=0, ymax= 3, xmin=-Inf, xmax=Inf, fill= "#D16D8C", alpha=0.003) + 
  stat_boxplot(geom ='errorbar', stat_params = list(width = 0.5))+
  geom_boxplot(fatten=0, outlier.colour="#73797A", outlier.size=1.2) + scale_y_continuous(limits=c(0,36), expand = c(0, 0))+
  stat_summary(fun.y=mean, geom="line", aes(group=1)) +
  theme(panel.border = element_rect(colour = "black", fill=NA))+
  labs(x= "Gene ID")+theme(axis.text.x = element_text(colour="black", angle = 90))+
  guides(fill = guide_colourbar(title= "PCC")) +
  theme(plot.margin = unit(c(10.5, 5.5, 5.5, 5.5), "points"), 
        legend.key.height= unit(0.25, "inches")) 

for (i in 1:length(curr_genes))  {
  g <- g + annotation_custom(
    grob = pointsGrob(pch = ifelse(curr_gini[i] =="0.5 - 0.75",2,3), gp = gpar(cex = 0.3,col="#386CAF")),
    xmin = curr$gene[sum(curr_len[1:i-1]) + 1],      # horizontal position of the pointGrob
    xmax = curr$gene[sum(curr_len[1:i-1]) + 1],
    ymin = 37,         # Note: The grobs are positioned outside the plot area
    ymax = 37)
}  

gt <- ggplot_gtable(ggplot_build(g))
gt$layout$clip[gt$layout$name == "panel"] <- "off"

tiff("Fig3C.tiff", res=300, width=2102.361, height= 727.44, unit="px")
grid.draw(gt)
dev.off()


# icSHAPE 4

load("./300M/invivo.300M.RData")
snr <- snr_invivo_300M
dat <- data.frame(mean= snr$mean_snr, gini=snr$gini_snr, pcc=snr$pcc, cov=snr$cov)
dat$gini <- replace(dat$gini, which(dat$gini<=0.25), 0.25)
dat$gini <- replace(dat$gini, which(dat$gini<=0.5 & dat$gini>0.25), 0.5)
dat$gini <- replace(dat$gini, which(dat$gini<=0.75 & dat$gini>0.5), 0.75)
dat$gini <- replace(dat$gini, which(dat$gini>0.75), 1)
dat$gini <- as.character(dat$gini)
dat$gini[which(dat$gini == "0.25")] <- "0.0 - 0.25"
dat$gini[which(dat$gini == "0.5")] <- "0.25 - 0.5"
dat$gini[which(dat$gini == "0.75")] <- "0.5 - 0.75"
dat$gini[which(dat$gini == "1")] <- "0.75 - 1.0"
dat$gini <- factor(dat$gini, levels = c("0.0 - 0.25", "0.25 - 0.5", "0.5 - 0.75", "0.75 - 1.0"))

tiff("FigS_clipping_icSHAPE_invitro_1.tiff", res=300, width=2102.361, height= 1000, unit="px")
ggplot(data=dat, aes(x=mean, y=pcc)) +  
  scale_colour_brewer(palette = "Accent") +
  geom_point(aes(shape= dat$gini), size= 0.7) +
  scale_x_continuous(limits=c(0,50), expand = c(0, 0)) +
  scale_y_continuous(limits=c(-0.25, 1.05), expand = c(0.02, 0.02)) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.3), 
        legend.position="top", legend.margin= unit(-5, "mm"), legend.box= "horizontal",
        legend.key.size=unit(6, "mm"), legend.background=element_rect(fill="transparent",colour=NA), 
        legend.key = element_rect(fill="transparent",colour=NA),
        legend.text= element_text(size=unit(5, "mm"))) +
  labs(y="Pearson correlation", x= "Mean SNR", shape="Gini index") +
  scale_shape_manual(values=c("0.0 - 0.25"= 0, "0.25 - 0.5"= 5, "0.5 - 0.75" = 2, "0.75 - 1.0" =3 )) +
  guides(shape= guide_legend(override.aes=list(size=2)))
dev.off()


#CQI

load("CQI.RData")

cor_height <- c(5, 0.5, 0.5)
for (i in 2:4) {
  tiff(paste0("Fig_S4_boostrap.snr_v_", names(cqi)[i], "_reactivity_cqi.tiff"), res = 300, height = 1.2, width = 1.9, units = 'in')
  print(ggplot(data.frame(x=boot_SNR, y=cqi[, i]), aes(x=x, y=y)) +
    geom_point(size=1) +scale_x_continuous(expand=c(0.1,0.1))+scale_y_log10()+
    theme(panel.border= element_rect(colour = "black", fill=NA, size=0.5),
          axis.title=element_blank(), axis.ticks=element_line(colour="black", size=0.2),
          axis.text=element_text(colour="black", size= 5), axis.text.y= element_text(angle=90),
          panel.grid=element_blank(), panel.background=element_rect(fill="white"))+
    geom_hline(yintercept= 1, linetype="dashed", size= 0.3)+
    annotate("text", x = 15, y = cor_height[i-1], size=2,
             label = paste0("r = ", round(cor(boot_SNR, cqi[, i], , use="pairwise.complete.obs"), 2))))
  dev.off() 
}
