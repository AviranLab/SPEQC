library (ggplot2)
library(grid)

load("./Mod-Seq_18SrRNA_rolling_mean_snr.RData")
arr_h <- 7.5
df1 <- data.frame(x1 = 505, x2 = 555, y1 = arr_h, y2 = arr_h)
df2 <- data.frame(x1=505, x2=505, y1=arr_h-0.1, y2=arr_h+0.1)
df3 <- data.frame(x1 = 555, x2 = 555, y1 = arr_h-0.1, y2 = arr_h+0.1)
df4 <- data.frame(x1=1133, x2=1183, y1=arr_h, y2=arr_h)
df5 <- data.frame(x1 = 1133, x2 = 1133, y1 = arr_h-0.1, y2 =arr_h+0.1)
df6 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)
df7 <- data.frame(x1=530, x2=530, y1=arr_h, y2=arr_h+0.3)
df8 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)
df9 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)
df10 <- data.frame(x1=1158, x2=1158, y1=arr_h, y2=arr_h+0.3)
df11 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)
df12 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)

g <- ggplot(data= rolling_mean_snr, aes(x= nucleotide, y= rolling_mean)) +
  geom_rect(ymin=5, ymax= Inf, xmin=-Inf, xmax=Inf, fill= "#6BD962", alpha=0.002)+
  geom_rect(ymin=3, ymax= 5, xmin=-Inf, xmax=Inf, fill= "#D1D088", alpha=0.003)+
  geom_rect(ymin=0, ymax= 3, xmin=-Inf, xmax=Inf, fill= "#D16D8C", alpha=0.003)+ 
  geom_bar(stat="identity", aes(fill= fraction_of_residues)) + scale_fill_gradient(low= "white", high="black")  +ylim(0,16) +
  guides(fill = guide_colourbar(title= NULL)) +
  scale_x_continuous(limits=c(0,1800), breaks=c(0, 500, 1000, 1500 ,1800), expand = c(0, 0)) +
  scale_y_continuous(limits=c(0,16), expand = c(0, 0))+
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.3))+
  labs(y="Rolling mean SNR", x= "Residue")+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df1)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df2)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df3)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df4)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df5)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df6)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df7)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df10)

g_inset <- ggplot(cov_info_selected, aes(y=mean_stop_counts, x=residues, fill= channel)) +
  geom_bar(stat="identity", position="dodge")+
  guides(fill = guide_legend(title= "Channel")) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=1),
        plot.background = element_rect(fill = "transparent",colour = NA),
        legend.background = element_rect(fill="transparent", linetype="solid"),
        legend.key.size= unit(0.2, "cm"),
        legend.text =element_text(size=6),
        axis.text.x = element_text(colour="black", size=7),
        axis.title.y = element_text(size=7),
        axis.text.y = element_text(colour = "black", size=7),
        legend.title= element_text(size=6))+
  labs(y="Mean counts", x= NULL) 
inset <- viewport(width=0.6, height=0.4, x=0.6, y=0.77)
tiff("Fig3A.tiff", res=300, width=2102.361, height= 727.44, unit="px")
print(g)
print(g_inset, vp=inset)
dev.off()
rm(list=ls())

load("./icSHAPE/300M/invivo.300M.RData")

# Fig. 3B

dat <- data.frame(mean= snr$mean_snr_clipped, gini=snr$gini_snr, pcc=snr$pcc, cov=snr$cov)
dat$gini <- replace(dat$gini, which(dat$gini<=0.25), 0.25)
dat$gini <- replace(dat$gini, which(dat$gini<=0.5 & dat$gini>0.25), 0.5)
dat$gini <- replace(dat$gini, which(dat$gini<=0.75 & dat$gini>0.5), 0.75)
dat$gini <- replace(dat$gini, which(dat$gini>0.75), 1)
dat$gini <- as.character(dat$gini)
dat$gini[which(dat$gini == "0.25")] <- "0.0 - 0.25"
dat$gini[which(dat$gini == "0.5")] <- "0.25 - 0.5"
dat$gini[which(dat$gini == "0.75")] <- "0.5 - 0.75"
dat$gini[which(dat$gini == "1")] <- "0.75 - 1.0"
dat$gini <- factor(dat$gini, levels = c("0.0 - 0.25", "0.25 - 0.5", "0.5 - 0.75", "0.75 - 1.0"))
dat$cov <- replace(dat$cov, which(dat$cov<=10), 10)
dat$cov <- replace(dat$cov, which(dat$cov<=15 & dat$cov>10), 15)
dat$cov <- replace(dat$cov, which(dat$cov<=20 & dat$cov>15), 20)
dat$cov <- replace(dat$cov, which(dat$cov<=25 & dat$cov>20), 25)
dat$cov <- replace(dat$cov, which(dat$cov>25), 30)
dat$cov <- as.character(dat$cov)
dat$cov <- replace(dat$cov, which(dat$cov== "10"), "0 - 10")
dat$cov <- replace(dat$cov, which(dat$cov== "15"), "10 - 15")
dat$cov <- replace(dat$cov, which(dat$cov== "20"), "15 - 20")
dat$cov <- replace(dat$cov, which(dat$cov== "25"), "20 - 25")
dat$cov <- replace(dat$cov, which(dat$cov== "30"), "> 25")
dat$cov <- factor(dat$cov, levels = c("0 - 10", "10 - 15", "15 - 20", "20 - 25", "> 25"))

g <- ggplot(data=dat, aes(x=mean, y=pcc)) +  
  scale_colour_brewer(palette = "Accent") +
  geom_point(aes(shape= dat$gini, colour=dat$cov), size= 0.6) +
  scale_x_continuous(limits=c(0,14), breaks=c(0, 3, 5, 10), expand = c(0, 0)) +
  scale_y_continuous(limits=c(-0.25, 1.05), expand = c(0.02, 0.02)) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.3), 
        legend.position="top", legend.margin= unit(-5, "mm"), legend.box= "horizontal",
        legend.key.size=unit(6, "mm"), legend.background=element_rect(fill="transparent",colour=NA), 
        legend.key = element_rect(fill="transparent",colour=NA),
        legend.text= element_text(size=unit(5, "mm"))) +
  labs(y="Pearson correlation", x= "Mean SNR", colour="Coverage", shape="Gini index") +
  scale_shape_manual(values=c("0.0 - 0.25"= 0, "0.25 - 0.5"= 5, "0.5 - 0.75" = 2, "0.75 - 1.0" =3 )) +
  guides(colour=guide_legend(override.aes=list(size=2)), shape= guide_legend(override.aes=list(size=2)))

dat_inset <- dat[which(dat$cov == "> 25"), ]
ty <- c(0:99.99)/100
tx <- sqrt(ty/(1-ty))
tx <- tx +median(dat_inset$mean - (sqrt(dat_inset$pcc/(1-(dat_inset$pcc)))), na.rm=T)
rows_a <- nrow(dat_inset)-length(tx)
df_fit <- data.frame(y=c(ty,rep(0,rows_a)), x= c(tx, rep(0,rows_a)))
dat_inset <- cbind(dat_inset, df_fit)

load("./icSHAPE/SHAPE-Seq_pcc_mean_snr.RData")
dat_julius <- data.frame(mean= c(mean_SNR_diff_clipped, 8), pcc= c(PCC_diff, 0.1))
df1 <- data.frame(x1 = 7.8, x2 = 8.2, y1 = 0, y2 = 0)
g_inset <- ggplot(dat_inset, aes(x=mean, y=pcc)) +  
  geom_point(shape=1, colour="#386CAF", size= 0.2)+#scale_shape_discrete(solid=T) +
  geom_point(data=data.frame(x= 8, y= 0.2), aes(x=x, y=y), 
             shape=1, colour="#386CAF", size= 0.4)+
  scale_x_continuous(limits=c(0,12), breaks=c(0, 3, 5, 10), expand = c(0, 0.2)) +
  scale_y_continuous(breaks = c(0, 0.5, 1), expand = c(0.02, 0.02)) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.3))+
  labs(x=NULL, y=NULL)+
  theme(plot.background = element_rect(fill = "transparent", colour = NA),
        panel.background= element_rect(fill = "#FFFFF9", colour = NA), 
        axis.text= element_text(colour="black", size=5), panel.grid= element_blank())+
  geom_line(aes(x=x, y=y)) + 
  geom_point(data= dat_julius, aes(x=mean, y=pcc), shape=4, color="red", size=0.8)+
  annotate("text", x = 9.5, y = 0.2, label = "icSHAPE", size= 2)+
  annotate("text", x = 9.7, y = 0.1, label = "SHAPE-Seq", size= 2)+
  annotate("text", x = 9.8, y = 0, label = "Theoretical fit", size= 2)+
  annotate("rect", xmin = 7.6, xmax = 11.5, ymin = - 0.07, ymax = 0.27, alpha = 0.1)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2), data = df1)

inset <- viewport(width=0.4, height=0.5, x=0.8, y=0.4)

tiff("Fig3B.tiff", res=300, width=2102.361, height= 1000, unit="px")
g
print(g_inset, vp=inset)
dev.off()


#Fig. 3C

clip_at <- 35
cov_t <- 25 #threshold for coverage
curr_snr <- unlist(snr$snr[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)])
curr_snr <- replace(curr_snr, which(curr_snr> 35), 35)
curr_len <- snr$len[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)]
curr_genes <- paste0("*", substring(snr$genes[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)], 14, 18))
curr_pcc <- snr$pcc[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)]
curr_gini <- snr$gini_snr[which(snr$mean_snr_clipped > 5 & snr$cov > cov_t)]
curr <- data.frame(SNR=curr_snr, gene=rep(curr_genes, curr_len), pcc= rep(curr_pcc, curr_len), gini=rep(curr_gini, curr_len))
curr_gini <- replace(curr_gini, which(curr_gini<=0.75 & curr_gini>0.5), 0.75)
curr_gini <- replace(curr_gini, which(curr_gini>0.75), 1)
curr_gini <- as.character(curr_gini)
curr_gini[which(curr_gini == "0.75")] <- "0.5 - 0.75"
curr_gini[which(curr_gini == "1")] <- "0.75 - 1.0"
curr$gene <- factor(curr$gene, levels = curr_genes)

g <- ggplot(curr, aes(factor(gene), SNR, fill=pcc)) +
  geom_rect(ymin=5, ymax= Inf, xmin=-Inf, xmax=Inf, fill= "#6BD962", alpha=0.003)+
  geom_rect(ymin=3, ymax= 5, xmin=-Inf, xmax=Inf, fill= "#D1D088", alpha=0.003)+
  geom_rect(ymin=0, ymax= 3, xmin=-Inf, xmax=Inf, fill= "#D16D8C", alpha=0.003) + 
  stat_boxplot(geom ='errorbar', stat_params = list(width = 0.5))+
  geom_boxplot(fatten=0, outlier.colour="#73797A", outlier.size=1.2) + scale_y_continuous(limits=c(0,36), expand = c(0, 0))+
  stat_summary(fun.y=mean, geom="line", aes(group=1)) +
  theme(panel.border = element_rect(colour = "black", fill=NA))+
  labs(x= "Gene ID")+theme(axis.text.x = element_text(colour="black", angle = 90))+
  guides(fill = guide_colourbar(title= "PCC")) +
  theme(plot.margin = unit(c(10.5, 5.5, 5.5, 5.5), "points"), 
        legend.key.height= unit(0.25, "inches")) 

for (i in 1:length(curr_genes))  {
  g <- g + annotation_custom(
    grob = pointsGrob(pch = ifelse(curr_gini[i] =="0.5 - 0.75",2,3), gp = gpar(cex = 0.3,col="#386CAF")),
    xmin = curr$gene[sum(curr_len[1:i-1]) + 1],      # horizontal position of the pointGrob
    xmax = curr$gene[sum(curr_len[1:i-1]) + 1],
    ymin = 37,         # Note: The grobs are positioned outside the plot area
    ymax = 37)
}  

gt <- ggplot_gtable(ggplot_build(g))
gt$layout$clip[gt$layout$name == "panel"] <- "off"

tiff("Fig3C.tiff", res=300, width=2102.361, height= 727.44, unit="px")
grid.draw(gt)
dev.off()


