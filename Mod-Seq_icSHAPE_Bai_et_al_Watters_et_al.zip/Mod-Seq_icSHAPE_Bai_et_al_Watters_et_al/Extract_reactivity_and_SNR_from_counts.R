#icSHAPE 
# rRNA: ENSMUSG00000065055, ENSMUSG00000064339
#NOTE : Uncomment lines 174-175 for in vitro data

dir <- "300M"
#change condition to invitro for in vitro data
condition <- "invivo"
library(ineq)
library(ggplot2)
#----------------------------------------------------------------------------------------
#A function for 2%- 8% normalization
#----------------------------------------------------------------------------------------
two.eight.normalize <- function(raw.estimates) {
  raw.estimates[which(raw.estimates == -999)] <- NA
  sorted <- raw.estimates[order(raw.estimates)]
  #   print(sorted)
  #   print(any(is.na(sorted)))
  if (any(is.na(sorted))) {
    normalize.range <- c(round((min(which(is.na(sorted)))-1) * .9), round((min(which(is.na(sorted)))-1) * .98))    
  } else {
    normalize.range <- c(round(length(sorted) * .9), round(length(sorted)* .98))
  }
  #   print(normalize.range)
  normalizer <- mean(sorted[normalize.range[1]:normalize.range[2]])
  #   print(normalizer)
  raw.estimates[which(raw.estimates != -999)] <- raw.estimates[which(raw.estimates != -999)] / normalizer
  #raw.estimates[which(is.na(raw.estimates))] <- -999
  # normalized.reactivity[normalized.reactivity < 0] <- 0
  return(raw.estimates)
}


#takes in file names and gives out a list which has geneIDs, length, overall and local coverages and counts for all genes present in both files
extract_info <- function(file_m, file_p) {
  conn_m <- file(file_m, open="r")
  conn_p <- file(file_p, open="r")
  
  lines_m <- readLines(conn_m)
  lines_p <- readLines(conn_p)
  closeAllConnections()
  
  genes_m <- c()
  
  for (i in 1:(length(lines_m)/2)) {
    genes_m[i] <- strsplit(lines_m[2*i-1], split=" ")[[1]][2]
  }
  
  genes_p <- c()
  for (i in 1:(length(lines_p)/2)) {
    genes_p[i] <- strsplit(lines_p[2*i-1], split=" ")[[1]][2]
  }
  
  genes <- intersect(genes_p, genes_m)
  cov_loc <- list(m=c(), p=c())
  cov_all <- list(m=c(), p=c())
  len <- c()
  start <- c()
  end <- c()
  counts <- list(m= list(), p=list())
  react_diff <- list()
  counter1 <- c()
  for (i in 1:length(genes)) {
    match_m <- which(genes_m == genes[i])
    match_p <- which(genes_p == genes[i])
    
    len_m <- as.numeric(strsplit(lines_m[2*match_m-1], split=" ")[[1]][8])
    len_p <- as.numeric(strsplit(lines_p[2*match_p-1], split=" ")[[1]][8])
    start_m <- as.numeric(strsplit(lines_m[2*match_m-1], split=" ")[[1]][6])
    start_p <- as.numeric(strsplit(lines_p[2*match_p-1], split=" ")[[1]][6])
    end_m <- as.numeric(strsplit(lines_m[2*match_m-1], split=" ")[[1]][7])
    end_p <- as.numeric(strsplit(lines_p[2*match_p-1], split=" ")[[1]][7])
    
    if (len_m == len_p & start_m==start_p) {
      len[i] <- len_m
      start[i] <- start_m
      end[i] <- end_m
      counts$m[[i]] <- as.numeric(strsplit(lines_m[2*match_m], split=" ")[[1]])
      counts$p[[i]] <- as.numeric(strsplit(lines_p[2*match_p], split=" ")[[1]])
    } else {
      len[i] <- max(end_p, end_m)- min(start_p, start_m)+1
      start[i] <- min(start_m, start_p)
      end[i] <- max(end_m, end_p)
      counts$m[[i]] <- c(rep(0,start_m - start[i]), 
                         as.numeric(strsplit(lines_m[2*match_m], split=" ")[[1]]),
                         rep(0,end[i] - end_m))
      counts$p[[i]] <- c(rep(0,start_p - start[i]), 
                         as.numeric(strsplit(lines_p[2*match_p], split=" ")[[1]]),
                         rep(0,end[i] - end_p))
    }
    
    cov_all$m[i] <- sum(counts$m[[i]])
    cov_all$p[i] <- sum(counts$p[[i]])
    cov_loc$m[i] <- cov_all$m[i]/len[i]
    cov_loc$p[i] <- cov_all$p[i]/len[i]
    react_diff[[i]] <- (counts$p[[i]]/cov_loc$p[[i]]) - (counts$m[[i]]/cov_loc$m[[i]])
    react_diff[[i]][which(react_diff[[i]] < 0)] <- 0
    react_diff[[i]] <- two.eight.normalize(react_diff[[i]])
    
  }
  return(list(genes=genes, cov_all=cov_all, cov_loc=cov_loc, start=start, end=end, len=len, counts_m=counts$m, counts_p=counts$p, react_diff=react_diff))
}

calcSNR <- function(rep1, rep2, clip_at= 35, cov_threshold= 200) {
  genes <- intersect(rep1$genes, rep2$genes)
  if (cov_threshold) {
    for (i in 1:length(genes)) {
      match1 <- which(rep1$genes == genes[i])
      match2 <- which(rep2$genes == genes[i])
      if (round(min(rep1$cov_loc$p[match1], rep2$cov_loc$p[match2])) < cov_threshold) genes[i] <- NA
    }
  }
  
  genes <- genes[which(!is.na(genes))]
  len <- c()
  snr <- list()
  mean_snr <- c()
  mean_snr_clipped <- c()
  mean_snr_clipped_new <- c()
  pcc <- c()
  cov_p <- c()
  cov_m <- c()
  gini_react <- c()
  gini_snr <- c()
  gini_snr_clipped <- c()
  frac_nans <- c()
  
  for (i in 1:length(genes)) {
    match1 <- which(rep1$genes== genes[i])
    match2 <- which(rep2$genes== genes[i])
    
    len1 <- rep1$len[match1]
    len2 <- rep2$len[match2]
    
    if (len1 == len2) {
      len[i] <- len1
      react1 <- rep1$react_diff[[match1]]
      react2 <- rep2$react_diff[[match2]]
      
    } else {
      
      sites1 <- rep1$start[[match1]]:rep1$end[[match1]]
      sites2 <- rep2$start[[match2]]:rep2$end[[match2]]
      len[i] <- length(which(sites1 %in% sites2))
      
      react1 <- rep1$react_diff[[match1]][which(sites1 %in% sites2)]
      react2 <- rep2$react_diff[[match2]][which(sites2 %in% sites1)]
      
    }
    
    gini1 <- ineq(react1, type="Gini")
    gini2 <- ineq(react2, type="Gini")
    gini_react[i] <- if (!any(is.na(c(gini1, gini2)))) mean(gini1, gini2, na.rm=T) else NA
    pcc[i] <- cor(react1, react2)
    cov_p[i] <- mean(rep1$cov_loc$p[match1], rep2$cov_loc$p[match2])
    cov_m[i] <- mean(rep1$cov_loc$m[match1], rep2$cov_loc$m[match2])
    snr[[i]] <- apply(cbind(react1, react2), 1, mean)/apply(cbind(react1, react2), 1, sd)
    #     snr[[i]][which(!is.finite(snr[[i]]))] <- NA
    
    gini_snr[i] <- ineq(snr[[i]][which(!is.na(snr[[i]]))], type="Gini")
    snr__ <- snr[[i]][which(!is.infinite(snr[[i]]))]
    gini_snr_clipped[i] <- ineq(replace(snr__, which(snr__ > clip_at), clip_at ), type="Gini")
    
    mean_snr[i] <- mean(snr[[i]], na.rm=T)
    mean_snr_clipped[i] <- mean(replace(snr[[i]], which(snr[[i]] > clip_at), clip_at), na.rm=T)
    frac_nans[i] <- length(which(is.nan(snr[[i]])))/length(snr[[i]])
    mean_snr_clipped_new[i] <- mean( replace(replace(snr[[i]], which(snr[[i]] > clip_at), clip_at), which(is.nan(snr[[i]])), 0), na.rm=T)
  }
  return(list(genes= genes, len=len, snr=snr, cov_p=cov_p, cov_m=cov_m, 
              gini_react=gini_react, gini_snr=gini_snr, gini_snr_clipped=gini_snr_clipped, 
              mean_snr=mean_snr, mean_snr_clipped=mean_snr_clipped, frac_nans = frac_nans,
              mean_snr_clipped_new=mean_snr_clipped_new, pcc=pcc))
}

filenames <- c("CountMod_dmso.1.tab", "CountMod_invivo.1.tab", 
               "CountMod_dmso.2.tab", "CountMod_invivo.2.tab")

# filenames <- c("CountMod_dmso.1.tab", "CountMod_invitro.1.tab", 
#                "CountMod_dmso.2.tab", "CountMod_invitro.2.tab")

for (exp in 1:2) {
  assign(paste0("Rep", exp), extract_info(filenames[2*exp-1], filenames[2*exp]))
}

snr <- calcSNR(Rep1, Rep2, , 0)

save(Rep1, Rep2, snr, file= paste0("./", dir, "/", condition, ".tab"))