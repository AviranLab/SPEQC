library(corrplot)
library(ggplot2)
library(reshape2)
library(foreach)
library(parallel)
library(doParallel)
library(plyr)
registerDoParallel(cores=detectCores(all.tests=TRUE))

#----------------------------------------------------------------------------------------
#A function for 2%- 8% normalization
#----------------------------------------------------------------------------------------
two.eight.normalize <- function(raw.estimates) {
  raw.estimates[which(raw.estimates == -999)] <- NA
  sorted <- raw.estimates[order(raw.estimates)]
  #   print(sorted)
  #   print(any(is.na(sorted)))
  if (any(is.na(sorted))) {
    normalize.range <- c(round((min(which(is.na(sorted)))-1) * .9), round((min(which(is.na(sorted)))-1) * .98))    
  } else {
    normalize.range <- c(round(length(sorted) * .9), round(length(sorted)* .98))
  }
  #   print(normalize.range)
  normalizer <- mean(sorted[normalize.range[1]:normalize.range[2]])
  #   print(normalizer)
  raw.estimates[which(raw.estimates != -999)] <- raw.estimates[which(raw.estimates != -999)] / normalizer
#   raw.estimates[which(is.na(raw.estimates))] <- -999
  # normalized.reactivity[normalized.reactivity < 0] <- 0
  return(raw.estimates)
} 

#----------------------------------------------------------------------------------------
#A function for bootstrapping data.
#----------------------------------------------------------------------------------------
bootstrap <- function(num_bootstrapSamples,num_biological_replicates, reads) {
  
  #a function to tell foreach how to combine lists of kind data as they are generated in parallel
  combine <- function(...) {
    
    all_lists <- list(...)
    list.combined <- list()
    
    pass_cal <- function(counts) return(c(0,cumsum(counts[1:(length(counts)-1)])))
    
    list.combined$minus.counts <- sapply(all_lists, function(x) x$minus.counts[-1])
    #list.combined$minus.counts <- sapply(all_lists, '[[', 'minus.counts')
    list.combined$minus.pass <- sapply(all_lists, function(x) pass_cal(x$minus.counts)[-1])
    #list.combined$minus.pass <- sapply(all_lists, function(x) pass_cal(x$minus.counts))
    list.combined$plus.counts <- sapply(all_lists, function(x) x$plus.counts[-1])
    list.combined$plus.pass <- sapply(all_lists, function(x) pass_cal(x$plus.counts)[-1])
    #list.combined$plus.counts <- sapply(all_lists, '[[', 'plus.counts')
    #list.combined$plus.pass <- sapply(all_lists, function(x) pass_cal(x$plus.counts))
    return(list.combined)
  }
  
  boot <- list()
  
  freq <- list(minus.counts="", plus.counts="")
  sampleSize <- list(minus.counts="", plus.counts="")
  
  sampleSize$minus.counts <- sum(reads$minus.counts)
  sampleSize$plus.counts <- sum(reads$plus.counts)
  
  freq$minus.counts <- reads$minus.counts/sampleSize$minus.counts
  freq$plus.counts <- reads$plus.counts/sampleSize$plus.counts
  
  boot <- foreach(i=1:num_bootstrapSamples , .combine = combine, .multicombine=TRUE) %dopar% SampleGenerator(freq, sampleSize)
  
  return(boot)
}

#----------------------------------------------------------------------------------------
#A function to generate minus channel and plus channel fragment counts
#Requires frequency of k-fragments in minus and plus channel and target sample sizes for paired end reads.
#Requires stops and passes for minus and plus channel and sample sizes for single end reads.
#----------------------------------------------------------------------------------------
SampleGenerator <- function (freq, sampleSize) {
  n <- length(freq$minus.counts)
  sample_gen <- list(minus.counts="", plus.counts="")
  sample_gen$minus.counts <- tabulate(sample(n, sampleSize$minus.counts, rep= TRUE, prob= freq$minus.counts), nbins=n)
  sample_gen$plus.counts <- tabulate(sample(n, sampleSize$plus.counts, rep= TRUE, prob= freq$plus.counts), nbins=n)
  
  return(sample_gen)
}

#---------------------------------------------------------------
#estimator
#---------------------------------------------------------------
estimate_summary <- function(boot) {
  
  n <- nrow(boot$minus.counts)
  num_resamples <- ncol(boot$minus.counts)
  gammas_boot <- boot$minus.counts/boot$minus.pass
  betas_boot <- (boot$plus.counts/boot$plus.pass)-gammas_boot
  betas_boot[which(betas_boot < 0, arr.ind= TRUE)] <- 0
  betas_boot <- two.eight.normalize(betas_boot)
  return(list(mean= apply(betas_boot, 1, mean), sdev= apply(betas_boot, 1, sd), nucleotide= 1:n))
}

#-------------------

dat_no_ligand = read.table(file="./TPP_Riboswitch_no_ligand_1M7.txt", header=T)
dat_with_ligand = read.table(file="./TPP_Riboswitch_5uM_ligand_1M7.txt", header=T)

beta_no_ligand <- as.numeric(levels(dat_no_ligand$beta[-1]))[dat_no_ligand$beta[-1]]
beta_with_ligand <- as.numeric(levels(dat_with_ligand$beta[-1]))[dat_with_ligand$beta[-1]]
n <- length(beta_no_ligand)

beta0_norm <- two.eight.normalize(beta_no_ligand)
beta5_norm <- two.eight.normalize(beta_with_ligand)

reads0 <- list(minus.counts = dat_no_ligand$untreated_mods, plus.counts = dat_no_ligand$treated_mods)

reads5 <- list(minus.counts = dat_with_ligand$untreated_mods, plus.counts = dat_with_ligand$treated_mods)

boot_no_ligand <- bootstrap(100, 1, reads0)
boot_with_ligand <- bootstrap(100, 1, reads5)

betas0_summary <- data.frame(estimate_summary(boot_no_ligand), type="betas0_summary")
betas5_summary <- data.frame(estimate_summary(boot_with_ligand), type="betas5_summary")
inter_experiment <- data.frame(mean= apply(cbind(beta_no_ligand, beta_with_ligand), 1, mean),
                               sdev= apply(cbind(beta_no_ligand, beta_with_ligand), 1, sd),
                               nucleotide= c(1:n), type="compared")

betas05 <- rbind(betas0_summary, betas5_summary)#Q, inter_experiment) 

SNR0 <- betas0_summary$mean/betas0_summary$sdev
SNR5 <- betas5_summary$mean/betas5_summary$sdev
SNR_inter <- inter_experiment$mean/inter_experiment$sdev

inter_experiment_norm <- data.frame(mean= apply(cbind(beta0_norm, beta5_norm), 1, mean),
                               sdev= apply(cbind(beta0_norm, beta5_norm), 1, sd),
                               nucleotide= c(1:n))
SNR_inter_norm <- inter_experiment_norm$mean/inter_experiment_norm$sdev

SNR_all <- data.frame(SNR=c(SNR0, SNR5, SNR_inter_norm), from=c(rep("Bootstrap_no_ligand", length(SNR0)), rep("Bootstrap_with_ligand", length(SNR5)), rep("Compare_two_condition", length(SNR_inter_norm))))
save(SNR0, SNR5, SNR_inter_norm, file="TPP_riboswitch.RData")