#Dip in 18S window SNR is because of very poor counts in all channels
library(ggplot2)
library(zoo)
library(grid)

sequence <- "TATCTGGTTGATCCTGCCAGTAGTCATATGCTTGTCTCAAAGATTAAGCCATGCATGTCT
AAGTATAAGCAATTTATACAGTGAAACTGCGAATGGCTCATTAAATCAGTTATCGTTTAT
TTGATAGTTCCTTTACTACATGGTATAACTGTGGTAATTCTAGAGCTAATACATGCTTAA
AATCTCGACCCTTTGGAAGAGATGTATTTATTAGATAAAAAATCAATGTCTTCGGACTCT
TTGATGATTCATAATAACTTTTCGAATCGCATGGCCTTGTGCTGGCGATGGTTCATTCAA
ATTTCTGCCCTATCAACTTTCGATGGTAGGATAGTGGCCTACCATGGTTTCAACGGGTAA
CGGGGAATAAGGGTTCGATTCCGGAGAGGGAGCCTGAGAAACGGCTACCACATCCAAGGA
AGGCAGCAGGCGCGCAAATTACCCAATCCTAATTCAGGGAGGTAGTGACAATAAATAACG
ATACAGGGCCCATTCGGGTCTTGTAATTGGAATGAGTACAATGTAAATACCTTAACGAGG
AACAATTGGAGGGCAAGTCTGGTGCCAGCAGCCGCGGTAATTCCAGCTCCAATAGCGTAT
ATTAAAGTTGTTGCAGTTAAAAAGCTCGTAGTTGAACTTTGGGCCCGGTTGGCCGGTCCG
ATTTTTTCGTGTACTGGATTTCCAACGGGGCCTTTCCTTCTGGCTAACCTTGAGTCCTTG
TGGCTCTTGGCGAACCAGGACTTTTACTTTGAAAAAATTAGAGTGTTCAAAGCAGGCGTA
TTGCTCGAATATATTAGCATGGAATAATAGAATAGGACGTTTGGTTCTATTTTGTTGGTT
TCTAGGACCATCGTAATGATTAATAGGGACGGTCGGGGGCATCAGTATTCAATTGTCAGA
GGTGAAATTCTTGGATTTATTGAAGACTAACTACTGCGAAAGCATTTGCCAAGGACGTTT
TCATTAATCAAGAACGAAAGTTAGGGGATCGAAGATGATCAGATACCGTCGTAGTCTTAA
CCATAAACTATGCCGACTAGGGATCGGGTGGTGTTTTTTTAATGACCCACTCGGCACCTT
ACGAGAAATCAAAGTCTTTGGGTTCTGGGGGGAGTATGGTCGCAAGGCTGAAACTTAAAG
GAATTGACGGAAGGGCACCACCAGGAGTGGAGCCTGCGGCTTAATTTGACTCAACACGGG
GAAACTCACCAGGTCCAGACACAATAAGGATTGACAGATTGAGAGCTCTTTCTTGATTTT
GTGGGTGGTGGTGCATGGCCGTTCTTAGTTGGTGGAGTGATTTGTCTGCTTAATTGCGAT
AACGAACGAGACCTTAACCTACTAAATAGTGGTGCTAGCATTTGCTGGTTATCCACTTCT
TAGAGGGACTATCGGTTTCAAGCCGATGGAAGTTTGAGGCAATAACAGGTCTGTGATGCC
CTTAGACGTTCTGGGCCGCACGCGCGCTACACTGACGGAGCCAGCGAGTCTAACCTTGGC
CGAGAGGTCTTGGTAATCTTGTGAAACTCCGTCGTGCTGGGGATAGAGCATTGTAATTAT
TGCTCTTCAACGAGGAATTCCTAGTAAGCGCAAGTCATCAGCTTGCGTTGATTACGTCCC
TGCCCTTTGTACACACCGCCCGTCGCTAGTACCGATTGAATGGCTTAGTGAGGCCTCAGG
ATCTGCTTAGAGAAGGGGGCAACTCCATCTCAGAGCGGAGAATTTGGACAAACTTGGTCA
TTTAGAGGAACTAAAAGTCGTAACAAGGTTTCCGTAGGTGAACCTGCGGAAGGATCATTA"

sequence <- unlist(strsplit(paste0((strsplit(sequence, split= "\n")[[1]]), collapse=""), split="")[[1]])

#----------------------------------------------------------------------------------------
#A function for 2%- 8% normalization
#----------------------------------------------------------------------------------------
two.eight.normalize <- function(raw.estimates) {
  raw.estimates[which(raw.estimates == -999)] <- NA
  sorted <- raw.estimates[order(raw.estimates)]
  #   print(sorted)
  #   print(any(is.na(sorted)))
  if (any(is.na(sorted))) {
    normalize.range <- c(round((min(which(is.na(sorted)))-1) * .9), round((min(which(is.na(sorted)))-1) * .98))    
  } else {
    normalize.range <- c(round(length(sorted) * .9), round(length(sorted)* .98))
  }
  #   print(normalize.range)
  normalizer <- mean(sorted[normalize.range[1]:normalize.range[2]])
  #   print(normalizer)
  raw.estimates[which(raw.estimates != -999)] <- raw.estimates[which(raw.estimates != -999)] / normalizer
  #raw.estimates[which(is.na(raw.estimates))] <- -999
  # normalized.reactivity[normalized.reactivity < 0] <- 0
  return(raw.estimates)
}


filenames <- paste0("./Mod-Seq/", c("Scer_WT_Rep1_minus.cnts", "Scer_WT_Rep2_minus.cnts", "Scer_WT_Rep1_plus.cnts", "Scer_WT_Rep2_plus.cnts"))

m1 <- list()
m2 <- list()
p1 <- list()
p2 <- list()
name_rRNA <- c("*18S_rRNA", "*58_25S_rRNA", "15S_rRNA", "21S_rRNA" )

for (rRNA in 1) {
  
  conn <- file(filenames[1], open="r")
  lines <- readLines(conn)
  m1[[rRNA]] <- as.numeric(strsplit(lines[[rRNA]], split=" ")[[1]])
  
  conn <- file(filenames[2], open="r")
  lines <- readLines(conn)
  m2[[rRNA]] <- as.numeric(strsplit(lines[[rRNA]], split=" ")[[1]])
  
  conn <- file(filenames[3], open="r")
  lines <- readLines(conn)
  p1[[rRNA]] <- as.numeric(strsplit(lines[[rRNA]], split=" ")[[1]])
  
  conn <- file(filenames[4], open="r")
  lines <- readLines(conn)
  p2[[rRNA]] <- as.numeric(strsplit(lines[[rRNA]], split=" ")[[1]])
  
}

closeAllConnections()

countNaNs <- function(x) {
  return(length(which(is.finite(x))))  
}

react1 <- list()
react2 <- list()
react1_diff <- list()
react2_diff <- list()
window.size= 51
window_align ="center"
window.SNR.median <- list()
window.SNR.mean <- list()
window.cov.mean <- list()
SNR <- list()
SNR_diff <- list()
for (i in 1) {
  m1[[i]][which(m1[[i]] == 0)] <- 1
  m2[[i]][which(m2[[i]] == 0)] <- 1
  
  m1_c <- sum(m1[[i]])
  m2_c <- sum(m2[[i]])
  p1_c <- sum(p1[[i]])
  p2_c <- sum(p2[[i]])
  
  react1_diff[[i]] <- (p1[[i]]/p1_c) - (m1[[i]]/m1_c)
  react1_diff[[i]][which(react1_diff[[i]] < 0)] <- 0
  react1_diff[[i]][which(sequence == "T" | sequence== "G")] <- NA
  react2_diff[[i]] <- (p2[[i]]/p2_c) - (m2[[i]]/m2_c)
  react2_diff[[i]][which(react2_diff[[i]] < 0)] <- 0
  react2_diff[[i]][which(sequence == "T" | sequence== "G")] <- NA
  SNR_diff[[i]] <- apply(cbind(two.eight.normalize(react1_diff[[i]]), two.eight.normalize(react2_diff[[i]])), 1, mean)/apply(cbind(two.eight.normalize(react1_diff[[i]]), two.eight.normalize(react2_diff[[i]])), 1, sd)
  
  SNR[[i]] <- replace(SNR_diff[[i]], which(SNR_diff[[i]] > 35), 35)
  Snr_na_fractions <- rollapply(SNR[[i]], FUN= function(x) length(which(is.finite(x))), width= window.size, align=window_align)/window.size
  window.SNR.mean[[i]] <- rollapply(SNR[[i]], FUN= mean, width= window.size, na.rm=T, align=window_align)
  
  nucleotides <- rollapply(1:length(SNR[[i]]), FUN= median, width= window.size, na.rm=T, align=window_align)
  window.SNR.mean[[i]][which(sequence[nucleotides] == "T" | sequence[nucleotides] == "G" )] <- NA
}

a= c(505, 1133)
b=c(555, 1183)
channels= c("p1", "p2", "m1", "m2")
names= c("Rep1 (+)", "Rep2 (+)", "Rep1 (-)", "Rep2 (-)")
d <- data.frame()
for (i in c(1,2)) {
  for (j in 1:4) {
    ch <- get(channels[j])[[1]]
    ch[which(sequence[nucleotides] == "T" | sequence[nucleotides] == "G")] <- NA
    d <- rbind(d, data.frame(ch= names[j], sites=paste0(a[i], "-", b[i]), m= mean(ch[a[i]:b[i]], na.rm= T)))
  }
}

for (j in 1:4) {
  ch <- get(channels[j])[[1]]
  ch <- get(channels[j])[[1]]
  d <- rbind(d, data.frame(ch= names[j], sites="Entire transcript", m= mean(ch, na.rm= T)))
}

d <- d[c(1:4, 9:12, 5:8),]
d$sites <- factor(d$sites, levels=unique(d$sites))


#----------------------------------------------
#Final figures
#----------------------------------------------
arr_h <- 7.5
df1 <- data.frame(x1 = 505, x2 = 555, y1 = arr_h, y2 = arr_h)
df2 <- data.frame(x1=505, x2=505, y1=arr_h-0.1, y2=arr_h+0.1)
df3 <- data.frame(x1 = 555, x2 = 555, y1 = arr_h-0.1, y2 = arr_h+0.1)
df4 <- data.frame(x1=1133, x2=1183, y1=arr_h, y2=arr_h)
df5 <- data.frame(x1 = 1133, x2 = 1133, y1 = arr_h-0.1, y2 =arr_h+0.1)
df6 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)
df7 <- data.frame(x1=530, x2=530, y1=arr_h, y2=arr_h+0.3)
df8 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)
df9 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)
df10 <- data.frame(x1=1158, x2=1158, y1=arr_h, y2=arr_h+0.3)
df11 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)
df12 <- data.frame(x1=1183, x2=1183, y1=arr_h-0.1, y2=arr_h+0.1)

g <- ggplot(data.frame(mean= replace(window.SNR.mean[[1]], which(window.SNR.mean[[1]] >35) ,35), 
                       nucleotide= nucleotides, na=Snr_na_fractions), 
            aes(x= nucleotide, y= mean, fill= Snr_na_fractions)) +
  geom_rect(ymin=5, ymax= Inf, xmin=-Inf, xmax=Inf, fill= "#6BD962", alpha=0.002)+
  geom_rect(ymin=3, ymax= 5, xmin=-Inf, xmax=Inf, fill= "#D1D088", alpha=0.003)+
  geom_rect(ymin=0, ymax= 3, xmin=-Inf, xmax=Inf, fill= "#D16D8C", alpha=0.003)+ 
  geom_bar(stat="identity") + scale_fill_gradient(low= "white", high="black")  +ylim(0,16) +
  guides(fill = guide_colourbar(title= NULL)) +
  scale_x_continuous(limits=c(0,1800), breaks=c(0, 500, 1000, 1500 ,1800), expand = c(0, 0)) +
  scale_y_continuous(limits=c(0,16), expand = c(0, 0))+
  theme(panel.border = element_rect(colour = "black", fill=NA, size=0.3))+
  labs(y="Rolling mean SNR", x= "Residue")+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df1)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df2)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df3)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df4)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df5)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df6)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df7)+
  geom_segment(aes(x = x1, y = y1, xend = x2, yend = y2),
               data = df10)

g_inset <- ggplot(d, aes(y=m, x=sites, fill= ch)) +geom_bar(stat="identity", position="dodge")+
  guides(fill = guide_legend(title= "Channel")) +
  theme(panel.border = element_rect(colour = "black", fill=NA, size=1),
        plot.background = element_rect(fill = "transparent",colour = NA),
        legend.background = element_rect(fill="transparent", linetype="solid"),
        legend.key.size= unit(0.2, "cm"),
        legend.text =element_text(size=6),
        axis.text.x = element_text(colour="black", size=7),
        axis.title.y = element_text(size=7),
        axis.text.y = element_text(colour = "black", size=7),
        legend.title= element_text(size=6))+
  labs(y="Mean counts", x= NULL) 
inset <- viewport(width=0.6, height=0.4, x=0.6, y=0.77)
tiff("Fig3A.tiff", res=300, width=2102.361, height= 727.44, unit="px")
print(g)
print(g_inset, vp=inset)
dev.off()
